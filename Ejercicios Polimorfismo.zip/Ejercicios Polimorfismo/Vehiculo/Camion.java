package Vehiculo;

public class Camion extends Vehiculo{
	private Remolque remolque;

	public Camion(String matricula) {
		super(matricula);
	}
	
	public void ponRemolque(Remolque remolque) {
		this.remolque = remolque;
	}
	
	public void quitarRemolque() {
		this.remolque = null;
	}
	
	@Override
	public void acelerar(int kmh) {
        super.acelerar(kmh);
        if (remolque != null && velocidad > 100) {
            System.out.println("¡Cuidado! El camion va demasiado rápido con el remolque.");
        }
	}      
    @Override
      public String toString() {
           String info = super.toString();
        		   if (remolque != null) {
        	            info += ", " + remolque.toString();
        	        }
           return info;
    }
}