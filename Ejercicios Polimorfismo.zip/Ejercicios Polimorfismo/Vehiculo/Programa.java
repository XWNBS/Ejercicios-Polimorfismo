package Vehiculo;

public class Programa {
	public static void main(String[] args) {
		Coche coche = new Coche ("1234ABC",4);
		Camion camion = new Camion ("5678DEF");
		Remolque remolque = new Remolque (2000);

		Vehiculo[] vehiculos = {coche, camion};
		
		for (Vehiculo v : vehiculos) {
            v.acelerar(50);
            System.out.println(v.toString());
        }

        System.out.println("Número de puertas del coche: " + coche.getNumPuertas());

        camion.ponRemolque(remolque);
        System.out.println(camion.toString());
        camion.acelerar(60); 
        System.out.println(camion.toString());
        
        camion.quitarRemolque();
        System.out.println(camion.toString());

	}

}
