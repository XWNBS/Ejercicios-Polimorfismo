package Vehiculo;

public abstract class Vehiculo {
	protected String matricula;
	protected int velocidad;

	public Vehiculo(String matricula) {
		this.matricula = matricula;
		this.velocidad = 0;
	}
	
	@Override 
	public String toString() {
		return "Matricula: " + matricula + ", velocidad" + velocidad + "km/h";
	}
	
	public void acelerar(int kmh) {
		this.velocidad += kmh;
	}


	public static void main(String[] args) {

	}

}
