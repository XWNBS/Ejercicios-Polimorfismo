package Empleados;

public class Programa {

	public static void main(String[] args) {
        Secretario secretario = new Secretario("Ana", "García", "12345678A", "Calle Mayor 1", "911111111", 25000, "Despacho 101", "912222222");
        Vendedor vendedor = new Vendedor("Carlos", "López", "87654321B", "Calle Menor 2", "622222222", 30000, "Ford Focus", "633333333", "Zona Norte");
        JefedeZona jefe = new JefedeZona("María", "Rodríguez", "11223344C", "Avenida Central 3", "644444444", 50000, "Despacho 201", "BMW Serie 3");

        Empleado[] empleados = {secretario, vendedor, jefe};

        for (Empleado emp : empleados) {
            System.out.println("\n--- Información del empleado ---");
            emp.imprimir();
            System.out.println("Salario antes del incremento: " + emp.salario);
            emp.incrementarSalario();
            System.out.println("Salario después del incremento: " + emp.salario);
            System.out.println("-----------------------------\n");
        }

        jefe.cambiarSecretario(secretario);
        jefe.darDeAltaVendedor(vendedor);
        vendedor.darDeAltaCliente("Cliente Nuevo");
        vendedor.cambiarCoche("Renault Megane");
    }
}
