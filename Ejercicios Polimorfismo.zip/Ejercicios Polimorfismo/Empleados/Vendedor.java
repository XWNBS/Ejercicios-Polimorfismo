package Empleados;

import java.util.ArrayList;
import java.util.List;


public class Vendedor extends Empleado {
    private String cocheEmpresa;
    private String telefonoMovil;
    private String areaVenta;
    private List<String> listaClientes;
    private double porcentajeComision;

    public Vendedor(String nombre, String apellidos, String DNI, String direccion, String telefono, double salario, String cocheEmpresa, String telefonoMovil, String areaVenta) {
        super(nombre, apellidos, DNI, direccion, telefono, salario);
        this.cocheEmpresa = cocheEmpresa;
        this.telefonoMovil = telefonoMovil;
        this.areaVenta = areaVenta;
        this.listaClientes = new ArrayList<>();
        this.porcentajeComision = 0.1;
    }

    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("Puesto: Vendedor");
        System.out.println("Coche de Empresa: " + cocheEmpresa);
        System.out.println("Teléfono Móvil: " + telefonoMovil);
        System.out.println("Área de Venta: " + areaVenta);
    }

    public void darDeAltaCliente(String cliente) {
        listaClientes.add(cliente);
    }

    public void darDeBajaCliente(String cliente) {
        listaClientes.remove(cliente);
    }

    public void cambiarCoche(String nuevoCoche) {
        this.cocheEmpresa = nuevoCoche;
    }

    @Override
    public void incrementarSalario() {
        salario *= 1.10; 
    }
}