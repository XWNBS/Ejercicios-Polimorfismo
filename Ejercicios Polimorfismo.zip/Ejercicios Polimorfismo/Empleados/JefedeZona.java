package Empleados;

import java.util.ArrayList;
import java.util.List;

public class JefedeZona extends Empleado {
    private String despacho;
    private Secretario secretario;
    private List<Vendedor> listaVendedores;
    private String cocheEmpresa;

    public JefedeZona(String nombre, String apellidos, String DNI, String direccion, String telefono, double salario, String despacho, String cocheEmpresa) {
        super(nombre, apellidos, DNI, direccion, telefono, salario);
        this.despacho = despacho;
        this.cocheEmpresa = cocheEmpresa;
        this.listaVendedores = new ArrayList<>();
    }

    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("Puesto: Jefe de Zona");
        System.out.println("Despacho: " + despacho);
        System.out.println("Coche de Empresa: " + cocheEmpresa);
    }

    public void cambiarSecretario(Secretario nuevoSecretario) {
        this.secretario = nuevoSecretario;
    }

    public void cambiarCoche(String nuevoCoche) {
        this.cocheEmpresa = nuevoCoche;
    }

    public void darDeAltaVendedor(Vendedor vendedor) {
        listaVendedores.add(vendedor);
    }

    public void darDeBajaVendedor(Vendedor vendedor) {
        listaVendedores.remove(vendedor);
    }

    @Override
    public void incrementarSalario() {
        salario *= 1.20; 
    }
}
