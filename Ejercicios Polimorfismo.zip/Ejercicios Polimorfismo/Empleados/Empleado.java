package Empleados;

public class Empleado {
	protected String nombre;
    protected String apellidos;
    protected String DNI;
    protected String direccion;
    protected int añosAntiguedad;
    protected String telefonoContacto;
    protected double salario;
    protected Empleado supervisor;

    public Empleado(String nombre, String apellidos, String DNI, String direccion, String telefono, double salario) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.DNI = DNI;
        this.direccion = direccion;
        this.telefonoContacto = telefono;
        this.salario = salario;
        this.añosAntiguedad = 0;
    }

    public void imprimir() {
        System.out.println("Empleado: " + nombre + " " + apellidos);
        System.out.println("DNI: " + DNI);
        System.out.println("Dirección: " + direccion);
        System.out.println("Teléfono: " + telefonoContacto);
        System.out.println("Salario: " + salario);
    }

    public void cambiarSupervisor(Empleado nuevoSupervisor) {
        this.supervisor = nuevoSupervisor;
    }

    public void incrementarSalario() {}
}