package Personas;

public class ProgramaDemo {
	 public static void main(String[] args) {
	        Estudiante estudiante = new Estudiante("Ana", "García", "E001", "Soltera", "Primer año");
	        Profesor profesor = new Profesor("Juan", "Pérez", "P001", "Casado", 2010, "D101", "Matemáticas");
	        PersonalServicio personal = new PersonalServicio("María", "López", "S001", "Divorciada", 2015, "D201", "Biblioteca");

	        System.out.println("\nPruebas de métodos:");
	        estudiante.cambiarEstadoCivil("Casada");
	        estudiante.matricularCurso("Segundo año");

	        profesor.reasignarDespacho("D102");
	        profesor.cambiarDepartamento("Lenguajes");

	        personal.trasladarSeccion("Secretaría");

	        System.out.println("\nInformación de individuos:");
	        imprimirInformacion(estudiante);
	        imprimirInformacion(profesor);
	        imprimirInformacion(personal);
	    }

	    private static void imprimirInformacion(Persona persona) {
	        System.out.println("\n" + persona.getClass().getSimpleName() + ":");
	        System.out.println("  Nombre: " + persona.nombre);
	        System.out.println("  Apellidos: " + persona.apellidos);
	        System.out.println("  Número de Identificación: " + persona.numeroIdentificacion);
	        System.out.println("  Estado Civil: " + persona.estadoCivil);

	        if (persona instanceof Empleado) {
	            Empleado empleado = (Empleado) persona;
	            System.out.println("  Año de Incorporación: " + empleado.anioIncorporacion);
	            System.out.println("  Número de Despacho: " + empleado.numeroDespacho);
	        }

	        if (persona instanceof Estudiante) {
	            Estudiante estudiante = (Estudiante) persona;
	            System.out.println(" Curso: " + estudiante.getCurso());
	        }

	        if (persona instanceof Profesor) {
	            Profesor profesor = (Profesor) persona;
	            System.out.println(" Departamento: " + profesor.getDepartamento());
	        }

	        if (persona instanceof PersonalServicio) {
	            PersonalServicio personalServicio = (PersonalServicio) persona;
	            System.out.println(" Sección: " + personalServicio.getSeccion());
	        }
	    }
	}