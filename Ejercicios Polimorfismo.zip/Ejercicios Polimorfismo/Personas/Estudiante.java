package Personas;

public class Estudiante extends Persona {
    private String curso;

    public Estudiante(String nombre, String apellidos, String numeroIdentificacion, 
                      String estadoCivil, String curso) {
        super(nombre, apellidos, numeroIdentificacion, estadoCivil);
        this.curso = curso;
    }

    public String getCurso() {
        return curso;
    }

    public void matricularCurso(String nuevoCurso) {
        this.curso = nuevoCurso;
    }
}
